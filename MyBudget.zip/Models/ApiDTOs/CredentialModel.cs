﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyBudget.Models.ApiDTOs
{
    public class CredentialModel
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}