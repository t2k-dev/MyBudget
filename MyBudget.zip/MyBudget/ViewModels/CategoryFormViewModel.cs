﻿using MyBudget.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyBudget.ViewModels
{
    public class CategoryFormViewModel
    {
        public Category Category { get; set; }                 
    }
}