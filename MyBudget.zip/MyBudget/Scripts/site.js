﻿$(document).ready(function () {       
    jQuery('#sandbox-container').datepicker({
        format: "MM yyyy",
        minViewMode: 1,
        todayBtn: "linked",
        language: "ru",
        autoclose: true        
    }).change(function () {        
        var month = jQuery(this).datepicker("getDate").getMonth() + 1;        
        var mnthStr = (month < 10) ? '0' + month.toString() : month.toString();
        var year = jQuery(this).datepicker("getDate").getFullYear().toString();
        var dt = mnthStr + year.toString();        
        window.location.href = '/Transactions/MyBudget/'+dt;
    });    


});