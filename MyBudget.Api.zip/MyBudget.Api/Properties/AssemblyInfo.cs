﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Управление общими сведениями о сборке осуществляется с помощью следующего 
// набора атрибутов. Измените значения этих атрибутов, чтобы изменить сведения,
// связанные с этой сборкой.
[assembly: AssemblyTitle("MyBudget.Api")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("MyBudget.Api")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2019")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Задание значения false для атрибута ComVisible делает типы в этой сборке невидимыми 
// для компонентов COM. Если требуется обратиться к типу в этой сборке через 
// компонент COM, задайте для атрибута ComVisible значение true у требуемого типа.
[assembly: ComVisible(false)]

// Следующий код GUID служит идентификатором (ID) библиотеки типов typelib, если этот проект доступен для COM
[assembly: Guid("e73ec522-5b85-4592-b806-dbb2442c3b29")]

// Сведения о версии сборки состоят из следующих четырех значений:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// Можно задать все значения или оставить номер сборки и номер редакции по умолчанию, 
// используя символ "*", как показано ниже:
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
